package com.simplilearn.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
@Repository
public class FeedbackDao {
@Autowired
private JdbcTemplate template;
public int addFedback(FeedbackEntity feedback) {
return template.update("insert into feedback(id,name,email,feedback) values (?,?,?,?)",
feedback.getId(),feedback.getName(),feedback.getEmail(),feedback.getFeedback());
}
}
