package com.simplilearn.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumeRestFulWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
